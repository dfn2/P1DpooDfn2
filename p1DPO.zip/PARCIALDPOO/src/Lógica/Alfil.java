package Lógica;

public class Alfil extends Pieza {

    public Alfil(int fila, int columna) {
        super(fila, columna);
    }

    public int calcularMovimientos() {

        int arribaDerecha = Math.min(8 - fila, 8 - columna);
        int arribaIzquierda = Math.min(8 - fila, columna - 1);
        int abajoDerecha = Math.min(fila - 1, 8 - columna);
        int abajoIzquierda = Math.min(fila - 1, columna - 1);

        return arribaDerecha + arribaIzquierda +
               abajoDerecha + abajoIzquierda;
    }
}