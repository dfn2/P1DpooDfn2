package Lógica;

public class Main {

    public static void main(String[] args) {

        Pieza peon = new Peon(2, 4);
        Pieza torre = new Torre(4, 3);
        Pieza alfil = new Alfil(4, 5);

        System.out.println("Movimientos del Peon: " + peon.calcularMovimientos());
        System.out.println("Movimientos de la Torre: " + torre.calcularMovimientos());
        System.out.println("Movimientos del alfil: " + alfil.calcularMovimientos());
    }
}
