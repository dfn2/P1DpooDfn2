package Lógica;

public class Peon extends Pieza {

    public Peon(int fila, int columna) {
        super(fila, columna);
    }
    public int calcularMovimientos() {

        int movimientos = 0;

        if (estaDentroTablero(fila + 1, columna)) {
            movimientos++;
        }

        if (fila == 2 && estaDentroTablero(fila + 2, columna)) {
            movimientos++;
        }

        return movimientos;
    }
}