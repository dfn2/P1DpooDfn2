package Lógica;

public class Torre extends Pieza {

	public Torre(int fila, int columna) {
		super(fila, columna);
	}

	public int calcularMovimientos() {

		int arriba = 8 - fila;
		int abajo = fila - 1;
		int derecha = 8 - columna;
		int izquierda = columna - 1;

		return arriba + abajo + derecha + izquierda;
	}
}


