package Lógica;

public abstract class Pieza {

    protected int fila;
    protected int columna;

    public Pieza(int fila, int columna) {
        this.fila = fila;
        this.columna = columna;
    }

    public boolean estaDentroTablero(int fila, int columna) {

        Tablero tablero = new Tablero();
        return tablero.esPosicionValida(fila, columna);
    }

    public abstract int calcularMovimientos();
}