package Lógica;

public class Tablero {

    private int Tamaño = 8;

    public boolean esPosicionValida(int fila, int columna) {

        if (fila >= 1 && fila <= Tamaño &&
            columna >= 1 && columna <= Tamaño) {
            return true;
        } else {
            return false;
        }
    }
}

